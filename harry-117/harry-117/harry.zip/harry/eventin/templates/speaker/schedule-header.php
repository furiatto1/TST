<?php
defined( 'ABSPATH' ) || exit;

?>
<h3 class="etn-title etn-schedule-wrap-title">
    <?php echo esc_html__('All Sessions by', 'harry'); ?>
    <?php echo esc_html(get_the_title()); ?>
</h3>