"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function ($) {
    var Elementor = function Elementor() {
        _classCallCheck(this, Elementor);
    };

    new Elementor();

    var SmarticTheme = function SmarticTheme() {
        _classCallCheck(this, SmarticTheme);
    };

    $(document).ready(function () {
        new SmarticTheme();
    });

    var Woocommerce = function Woocommerce() {
        _classCallCheck(this, Woocommerce);
    };

    new Woocommerce();
})(jQuery);
//# sourceMappingURL=theme.js.map
