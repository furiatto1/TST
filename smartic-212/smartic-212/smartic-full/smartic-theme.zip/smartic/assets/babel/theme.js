class SmarticTheme {

}

$(document).ready(function () {
    new SmarticTheme();
})
