<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
the_tags('<div class="g5blog__single-meta-tag tagcloud"><i class="fal fa-tags"></i>','','</div>');
