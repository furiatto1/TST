G5THEME USAGE LICENSE

By using our product, you agree to the following terms:

1. License
Our Commercial WordPress themes (Premium wordpress themes) are released under the GNU Public License 3.0. 

2. Ownership
You may not claim intellectual or exclusive ownership to any of our products, modified or unmodified.

3. Photos Copyright Info
When viewing the theme demos in the gallery http://themes.g5plus.net you will see several photographic images used. Our themes do not come packaged with any copyrighted photography. The photos used in the demos are purely for demonstration purposes, and are used to give the visitor a functional preview of what the theme will look like once content has been added. These photos should not be saved, copied or redistributed in any way.
