<?php
/**
 * The template for displaying all pages
 *
 * @since 1.0
 * @version 1.0
 */

get_header();
homeid_get_template('page');
get_footer();
