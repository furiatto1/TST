<?php
/**
 * The template for displaying archive pages
 *
 * @since 1.0
 * @version 1.0
 */

do_action('homeid_search_content');