<?php
// Get Categories for posts.
?>
<div class="entry-meta-cat">
	<?php the_category()?>
</div>