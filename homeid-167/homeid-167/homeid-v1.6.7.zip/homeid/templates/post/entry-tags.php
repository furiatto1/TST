<?php
the_tags('<div class="tagcloud"><i class="fal fa-tags"></i>','','</div>');
