<div class="site-search-results-not-found">
	<h2><?php esc_html_e('Nothing found','homeid') ?></h2>
	<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'homeid' ); ?></p>
	<?php get_search_form(); ?>
</div>