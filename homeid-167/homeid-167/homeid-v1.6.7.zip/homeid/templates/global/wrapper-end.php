<?php
/**
 * The template for displaying wrapper-end
 *
 * @since 1.0
 * @version 1.0
 */
?>
			</div> <!-- End Primary Content Inner -->
			<?php get_sidebar(); ?>
		</div> <!-- End Primary Content Row -->
	</div> <!-- End Primary Content Container -->
</div> <!-- End Primary Content Wrapper -->
<?php do_action('homeid_after_main_content'); ?>