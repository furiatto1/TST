<?php
/**
 * @hooked homeid_template_page_content, 10
 */
do_action('homeid_page_content');