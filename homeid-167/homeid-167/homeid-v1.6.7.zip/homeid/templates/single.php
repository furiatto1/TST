<?php
/**
 * @hooked homeid_template_single_content, 10
 */
do_action('homeid_single_content');