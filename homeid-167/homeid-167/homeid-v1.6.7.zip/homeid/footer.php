<?php
/**
 * The template for displaying the footer
 *
 * @since 1.0
 * @version 1.0
 */
homeid_get_template('global/site-end');
?>
<?php wp_footer(); ?>
</body>
</html> <!-- end of site. what a ride! -->
