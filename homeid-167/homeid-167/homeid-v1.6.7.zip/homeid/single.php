<?php
/**
 * The template for displaying all single posts
 *
 * @since 1.0
 * @version 1.0
 */

get_header();
homeid_get_template('single');
get_footer();
