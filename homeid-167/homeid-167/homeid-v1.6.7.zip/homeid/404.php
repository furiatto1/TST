<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @since 1.0
 * @version 1.0
 */

get_header();
homeid_get_template('404');
get_footer();