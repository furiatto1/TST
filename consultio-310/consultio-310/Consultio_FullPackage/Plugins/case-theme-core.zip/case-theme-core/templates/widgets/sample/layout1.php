<?php
    $data = array(
        'id' => '29da9e5',
        'elType' => 'column',
        'settings'=>[
            '_column_size' => 100
        ],
        'elements' => [],
        'isInner' => false,
    );
    $args = [];
    $column = new \Elementor\Element_Column($data, $args);
    $column->print_element();
?>