/**
 * @team: FsFlex Team
 * @since: 1.0.0
 * @author: Case Themes
 */
(function ($) {
    console.log($('.ct-icon-picker'));
})(jQuery);
